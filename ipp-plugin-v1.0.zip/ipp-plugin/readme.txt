=== IPP - Instant Page Prefetcher (Backend + Frontend) ===
Contributors: mihaiioan
Author link: https://idh.ro
Donate link: https://ko-fi.com/ejohnnyro
Tags: performance, prefetch, speed optimization, page load
Requires at least: 4.7
Tested up to: 6.6.2
Stable tag: 1.1
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin to improve page load times by prefetching links.

== Description ==

The Instant Page Prefetcher plugin enhances your site's performance by prefetching links when users hover over them, enabling pages to load faster.

Key Features:
* Optimizes page load times with minimal setup.
* Prefetches only when necessary to save bandwidth.
* Compatible with both the frontend and WordPress admin dashboard.
* Built for speed and ease of use.

This plugin is free to use and is licensed under GPLv2 or later, just like WordPress.

**How it Works:**
When a user hovers over a link, the plugin preloads the destination page in the background, speeding up subsequent page loads without impacting your server's performance.

== Frequently Asked Questions ==

= How does this plugin improve performance? =

The plugin prefetches pages in the background when users hover over links, allowing pages to load almost instantly when clicked.

= Is this plugin compatible with other caching and optimization plugins? =

Yes, Instant Page Prefetcher is compatible with most caching and optimization plugins. It works alongside them to improve overall performance.

== Screenshots ==

1. Settings (off, frontend, backend, both mode)

== Changelog ==

### 1.1
- Fixed minor bugs from the initial release of IPP - Instant Page Prefetcher (Backend + Frontend).
- Added functionality to prefetch pages for improved load times in both backend and frontend.
- Implemented settings page for user configuration options.
- Included activation notice upon plugin activation.
- Ensured proper escaping of output to enhance security (replaced `_e` with `esc_html_e` and `esc_attr_e`).
- Fixed mismatched text domain to match plugin slug.
- Corrected mismatched plugin name in the plugin header.

### 1.0
- Initial release of IPP - Instant Page Prefetcher (Backend + Frontend).
- Added functionality to prefetch pages for improved load times in both backend and frontend.
- Implemented settings page for user configuration options.
- Included activation notice upon plugin activation.

== Upgrade Notice ==

= 1.1 =
This update fixes minor bugs from the initial release. Install for enhanced performance and stability.

== License ==

This plugin is licensed under GPLv2 or later, ensuring freedom to use, modify, and share.

== Plugin Features ==

* Fast prefetching for improved user experience
* Easy integration into your existing WordPress site
* Works on both frontend and WordPress dashboard
