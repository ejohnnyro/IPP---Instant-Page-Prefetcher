<?php
/**
 * Plugin Name: IPP - Instant Page Prefetcher (Backend + Frontend)
 * Plugin URI: https://idh.ro/ipp-plugin
 * Description: A WordPress plugin to prefetch pages and improve load times in backend and frontend.
 * Version: 1.0
 * Author: Ioan Mihai
 * Author URI: https://dev.ejohnny.ro
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ipp-instant-page-prefetcher-backend-frontend
 */

// Enqueue the Instant Page script in frontend
function ipp_enqueue_frontend() {
    $setting = get_option('ipp_options', 'off'); // Get the current setting

    // Only enqueue for frontend if setting is not 'off'
    if ($setting === 'frontend' || $setting === 'both') {
        wp_enqueue_script(
            'ipp',
            plugins_url('/ipp.js', __FILE__),
            array(),
            '1.0',
            true
        );
    }
}

// Enqueue the Instant Page script in backend
function ipp_enqueue_backend() {
    $setting = get_option('ipp_options', 'off'); // Get the current setting

    // Only enqueue for backend if setting is not 'off'
    if ($setting === 'backend' || $setting === 'both') {
        wp_enqueue_script(
            'ipp-admin',
            plugins_url('/ipp.js', __FILE__),
            array(),
            '1.0',
            true
        );
    }
}

// Enqueue scripts for frontend
add_action('wp_enqueue_scripts', 'ipp_enqueue_frontend'); // For frontend scripts

// Enqueue scripts for backend
add_action('admin_enqueue_scripts', 'ipp_enqueue_backend'); // For backend scripts

// Display a notification after the plugin is activated
function ipp_activation_notice() {
    if (get_option('ipp_notice')) {
        ?>
        <div id="message" class="notice is-dismissible updated">
            <p><?php _e('IPP - Instant Page Prefetcher has been activated! You can now enjoy faster loading times on your WordPress site.', 'ipp-instant-page-prefetcher-backend-frontend'); ?></p>
            <button type="button" class="notice-dismiss">
                <span class="screen-reader-text"><?php _e('Close notification.', 'ipp-instant-page-prefetcher-backend-frontend'); ?></span>
            </button>
        </div>
        <?php
    }
}

// Hook the activation notice to admin_notices
add_action('admin_notices', 'ipp_activation_notice');

// Register activation hook
function ipp_activate() {
    add_option('ipp_notice', true);
    add_option('ipp_options', 'off'); // Set default option to 'off'
}
register_activation_hook(__FILE__, 'ipp_activate');

// Add submenu page under Settings
function ipp_add_settings_page() {
    add_options_page(
        __('IPP Settings', 'ipp-instant-page-prefetcher-backend-frontend'), // Page title
        __('IPP Settings', 'ipp-instant-page-prefetcher-backend-frontend'), // Menu title
        'manage_options',                  // Capability
        'ipp-settings',                    // Menu slug
        'ipp_render_settings_page'         // Callback function
    );
}

add_action('admin_menu', 'ipp_add_settings_page');

// Render the settings page
function ipp_render_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('IPP Settings', 'ipp-instant-page-prefetcher-backend-frontend'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('ipp_options_group'); // Group name
            do_settings_sections('ipp-settings');  // Page slug
            ?>
            <h2><?php _e('Select IPP Mode', 'ipp-instant-page-prefetcher-backend-frontend'); ?></h2>
            <p>
                <label>
                    <input type="radio" name="ipp_options" value="off" <?php checked(get_option('ipp_options'), 'off'); ?> />
                    <?php _e('Off', 'ipp-instant-page-prefetcher-backend-frontend'); ?>
                </label><br>
                <label>
                    <input type="radio" name="ipp_options" value="backend" <?php checked(get_option('ipp_options'), 'backend'); ?> />
                    <?php _e('Backend Mode', 'ipp-instant-page-prefetcher-backend-frontend'); ?>
                </label><br>
                <label>
                    <input type="radio" name="ipp_options" value="frontend" <?php checked(get_option('ipp_options'), 'frontend'); ?> />
                    <?php _e('Frontend Mode', 'ipp-instant-page-prefetcher-backend-frontend'); ?>
                </label><br>
                <label>
                    <input type="radio" name="ipp_options" value="both" <?php checked(get_option('ipp_options'), 'both'); ?> />
                    <?php _e('Backend and Frontend Mode', 'ipp-instant-page-prefetcher-backend-frontend'); ?>
                </label>
            </p>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register settings
function ipp_register_settings() {
    register_setting('ipp_options_group', 'ipp_options'); // Group name and option name
}

add_action('admin_init', 'ipp_register_settings');
